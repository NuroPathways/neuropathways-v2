import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { base44 } from "@/api/entities";
import { useAuth } from "@/lib/AuthContext";
import SupportNowOverlay from "@/components/support/SupportNowOverlay";
import RoleAwareShell from "@/components/navigation/RoleAwareShell";
import { createRoleNavigation, mobilePrimaryKeysForRole, resolveNavigationRole } from "@/components/navigation/navigationModels";

const noLayoutPages = ["Splash", "Login", "RoleSelection", "ClinicianLogin", "ParentLogin", "ParentSignup", "ParentQuickStart", "ParentHome", "ClientLogin", "RoleSetup", "HelpNow", "AIChat"];

export default function Layout({ children, currentPageName }) {
  const { user, isLoadingAuth } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [childrenList, setChildrenList] = useState([]);
  const [isIndividualFallback, setIsIndividualFallback] = useState(false);
  const [supportRequest, setSupportRequest] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setChildrenList([]);
    setIsIndividualFallback(false);
    if (!user) return () => { cancelled = true; };
    if (["parent_free", "legacy_family"].includes(user.account_type || user.accountType)) {
      // These children were authorized by /parent/session. Never look them up
      // through clinician-cookie legacy endpoints using a capability namespace.
      setChildrenList((user.parent_children || []).map(child => ({
        ...child, child_name: child.name || child.child_name,
      })));
      return () => { cancelled = true; };
    }

    if (user.invite_token) {
      setChildrenList(
        Array.isArray(user.children) && user.children.length
          ? user.children
          : user.id ? [{ id: user.id, child_name: user.child_name }] : []
      );
      return () => { cancelled = true; };
    }

    if (user.app_role === "clinician" || user.role === "admin") {
      base44.entities.Child.filter({ clinician_id: user.id })
        .then((children) => { if (!cancelled) setChildrenList(children); })
        .catch(() => {});
    } else if (
      ["parent", "caregiver"].includes(user.app_role) ||
      ["parent", "caregiver"].includes(user.role) ||
      ["parent", "parent_family", "family", "caregiver"].includes(user.account_type)
    ) {
      Promise.all([
        base44.entities.Child.filter({ parent_id: user.id }).catch(() => []),
        user.email ? base44.entities.Child.filter({ parent_email: user.email }).catch(() => []) : Promise.resolve([]),
      ]).then(([byId, byEmail]) => {
        if (cancelled) return;
        const uniqueChildren = new Map();
        for (const child of [...byId, ...byEmail]) uniqueChildren.set(child.id, child);
        const children = Array.from(uniqueChildren.values());
        setChildrenList(children);
        if (!user.account_type) {
          const familyId = user.linked_family_id || children[0]?.family_id;
          if (familyId) {
            base44.entities.Family.filter({ id: familyId })
              .catch(() => [])
              .then((families) => {
                if (!cancelled && families[0]?.account_type === "individual") setIsIndividualFallback(true);
              });
          }
        }
      });
    }
    return () => { cancelled = true; };
  }, [user?.id, user?.app_role, user?.role, user?.account_type, user?.invite_token, user?.children, user?.email]);

  if (noLayoutPages.includes(currentPageName)) return <>{children}</>;

  if (isLoadingAuth) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <>{children}</>;

  const role = resolveNavigationRole(user, isIndividualFallback);
  const homePath = user.invite_token ? "/ClientHome" : "/ParentHome";
  const requestedChildId = new URLSearchParams(location.search).get("child_id");
  let savedChildId = null;
  try { savedChildId = localStorage.getItem(`np-family-child:${user.id}`); } catch { /* Storage may be unavailable. */ }
  const currentChildId = requestedChildId || (childrenList.some((child) => String(child.id) === String(savedChildId)) ? savedChildId : null)
    || (childrenList.some((child) => String(child.id) === String(user.child_id)) ? user.child_id : null)
    || (childrenList.length === 1 ? childrenList[0]?.id : null);
  const selectedChild = role === "caregiver" && childrenList.length
    ? childrenList.find((child) => String(child.id) === String(currentChildId)) || null
    : null;
  const hasPortalChildContext = role === "caregiver" && Boolean(user.invite_token);
  const accountName =
    (user.display_name || user.full_name || user.primary_contact)?.trim() ||
    (role === "individual" ? user.child_name : "") ||
    (user.email && !user.email.endsWith("@clients.neuropathways.app")
      ? user.email.split("@")[0].split(/[._-]/)[0].replace(/^(.)/, (letter) => letter.toUpperCase())
      : "") ||
    childrenList[0]?.child_name ||
    "Account";
  const accountMeta = role === "clinician"
    ? "Clinical team"
    : role === "individual"
      ? "Individual account"
      : "Family account";
  const baseGroups = createRoleNavigation(role, homePath, role === "caregiver" && !user.invite_token);
  const navigationGroups = baseGroups.map((group) => ({
    ...group,
    items: group.items.map((item) => {
      const openSupportOverlay = item.key === "support" && role !== "clinician";
      return {
        ...item,
        active: item.pages?.includes(currentPageName) || false,
        to: openSupportOverlay ? undefined : item.to && ((path) => {
          if ((!user.invite_token && role !== "caregiver") || path === "/ClientHome") return path;
          const childId = selectedChild?.id || currentChildId;
          if (!childId) return path;
          const [pathname, query = ""] = path.split("?");
          const params = new URLSearchParams(query);
          params.set("child_id", childId);
          return `${pathname}?${params.toString()}`;
        })(item.to),
        onSelect: openSupportOverlay ? () => setSupportRequest((request) => request + 1) : item.onSelect,
        disabled: openSupportOverlay && childrenList.length === 0,
      };
    }),
  }));
  const isLegacyDashboard = currentPageName === "ClinicianDashboard";
  const dashboardOrder = ["dashboard", "clients", "plans", "documents", "reports", "messages", "settings"];
  const navigationItems = navigationGroups.flatMap((group) => group.items);
  const groups = isLegacyDashboard ? [
    {
      label: "",
      items: dashboardOrder.map((key) => navigationItems.find((item) => item.key === key)).filter(Boolean)
        .map((item) => ({ ...item, label: item.key === "clients" ? "Users" : item.label })),
    },
    { label: "More tools", items: navigationItems.filter((item) => !dashboardOrder.includes(item.key)) },
  ] : navigationGroups;
  const currentItem = groups.flatMap((group) => group.items).find((item) => item.active);
  const currentLabel = currentItem?.label || currentPageName;
  const mobilePrimaryKeys = mobilePrimaryKeysForRole(role);

  const handleChildSelect = (childId) => {
    try { localStorage.setItem(`np-family-child:${user.id}`, childId); } catch { /* Storage may be unavailable. */ }
    if (user.invite_token) {
      const params = new URLSearchParams(location.search);
      params.set("child_id", childId);
      navigate(`${location.pathname}?${params.toString()}`);
    } else {
      const params = new URLSearchParams(location.search);
      params.set("child_id", childId);
      navigate(`${location.pathname}?${params.toString()}`);
    }
  };

  return (
    <RoleAwareShell
      role={role}
      roleLabel={role === "clinician" ? isLegacyDashboard ? "Clinician Portal" : "Clinician workspace" : role === "individual" ? "Your personal space" : "Caregiver workspace"}
      legacyAppearance={isLegacyDashboard}
      hideTopbar={isLegacyDashboard}
      currentLabel={currentLabel}
      activeKey={currentItem?.key}
      navGroups={groups}
      mobilePrimaryKeys={mobilePrimaryKeys}
      accountName={accountName}
      accountMeta={accountMeta}
      selectedChild={role === "caregiver" ? selectedChild : null}
      childrenOptions={role === "caregiver" ? childrenList : []}
      contextLabel="Viewing support for"
      onChildSelect={role === "caregiver" && childrenList.length > 1 ? handleChildSelect : undefined}
      onLogout={() => base44.auth.logout("/")}
    >
      {children}
      {role !== "clinician" && (
        <SupportNowOverlay
          user={user}
          children={childrenList}
          isIndividual={role === "individual"}
          openRequest={supportRequest}
          autoOpen={false}
        />
      )}
    </RoleAwareShell>
  );
}
